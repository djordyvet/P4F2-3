#!/bin/bash

#Do not modify this file
export ROS_CONTROLLER_IP=10.10.10.10
export ROS_MASTER_URI=http://$ROS_CONTROLLER_IP:11311
export ROS_IP=$ROS_CONTROLLER_IP
